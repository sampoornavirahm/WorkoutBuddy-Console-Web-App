# 1,300+ Exercise Animation Dataset Integration

Integrate the complete 1,324 exercise animation database from `hasaneyldrm/exercises-dataset` into the Workout Companion Web Console, providing instant client-side catalog browsing, multi-facet filtering, high-performance lazy-loaded GIF cards, deep Routine Builder integration, and optional Firestore admin synchronization.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural and UX decisions were confirmed during the planning clarification interview:

- **Confirmed Decision 1 (Storage & Delivery)**: Instant bundled catalogue (1,324 items loaded zero-latency without hitting Firestore read quotas) with optional one-click admin Firestore synchronization for cloud backup and custom overrides.
- **Confirmed Decision 2 (Media Display)**: Lazy-loaded animated GIF previews paired with static WebP/JPEG posters and high-performance virtualized grid rendering to ensure smooth 60fps scrolling on both desktop and connected TV displays.
- **Confirmed Decision 3 (Browsing & Discovery)**: Multi-facet filtering system covering Target Muscle Groups (Chest, Back, Legs, Arms, Core, Shoulders, Cardio, Full Body), Equipment (Bodyweight, Dumbbell, Barbell, Cable, Machine, Kettlebell, Band), and Difficulty levels (Beginner, Intermediate, Advanced) with instant full-text search.

---

## 1. Overview & Core Concept

- **What It Does**: Unlocks the entire 1,324 animated exercise library across the web console. Athletes, coaches, and administrators can search, preview animated biomechanical movements, inspect step-by-step coaching cues, filter across equipment and muscles, and instantly assemble exercises into personalized routines playable on LG webOS TV.
- **Target Audience & Context**: Coaches, personal trainers, and athletes designing structured workouts on the web console, and home athletes following visual exercise cues on the big screen.
- **Key Value**: Expands the exercise library from a 60-item curated subset to a comprehensive 1,324-movement visual dictionary with zero cloud latency and no paywalled assets.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Exploration & Faceted Search (`ExerciseManagerView`)**:
   - User navigates to the **Exercises** tab.
   - A stat strip displays `1,324 Verified Exercises · 100% Animated`.
   - The user searches "Arnold Press" or filters by "Shoulders" + "Dumbbell" + "Intermediate".
   - The grid filters instantly in $<50\text{ms}$.
   - Cards display animated loop previews on intersection, muscle tags (`Deltoids · Triceps`), and equipment badges without UI clutter.
2. **Detailed Exercise Inspection (`ExerciseModal`)**:
   - Clicking any exercise opens a modal with a high-resolution animation player, loop toggles, target muscle anatomy callout, full step-by-step instructions, and attribution source.
   - One-click action: `"Add to Routine"`.
3. **Routine Assembly with Full Library (`RoutineBuilderView`)**:
   - In the Routine Builder, clicking `"+ Add Exercise"` opens an optimized Drawer populated with the full 1,324 catalog.
   - Users can search and filter the entire library, preview animations inline, set reps/sets/work/rest timings, and insert into the routine.
4. **Admin Cloud Sync (`Admin Sync Tool`)**:
   - Admins see an optional `"Sync 1,324 Exercises to Cloud Firestore"` button with batching progress modal (50 docs per commit) to sync or restore customized cloud records without exceeding rate limits.

### Visual Identity & Theme

- **Aesthetic Direction**: Utilitarian Athletic Studio — sleek, high-contrast typography, crisp borders, and distraction-free media playback.
- **Color Palette**:
  - Neutral Canvas: `#FAFAF8` (warm gallery off-white) with dark mode `#0E1117`.
  - Structural Surfaces: Pure white `#FFFFFF` cards with hairline border `rgba(0, 0, 0, 0.08)`.
  - Accent Budget (10%): High-intent athletic accents `#171615` (obsidian black CTA), `#2563EB` (cobalt blue focus & sync), and `#16A34A` (success check).
- **Typography & Formatting**:
  - Primary UI: `Plus Jakarta Sans` for clean, modern legibility.
  - Metrics & Timers: `font-mono tabular-nums` for rock-solid timing and counter alignments.
  - Zero-Pill Discipline: Unboxed metadata tags separated by `·` (`Dumbbell · Biceps · Beginner`).
- **Interactive Feedback & Motion**:
  - Image/GIF cards feature progressive skeleton loaders and aspect-ratio locks (`aspect-video` or `aspect-square`) preventing layout shift.
  - Lazy loading with `loading="lazy"` and `IntersectionObserver` to only decode animated GIFs visible in the viewport.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Client-Side Bundled Dataset vs. Pure Remote Firestore Querying**
  - *Chosen Approach*: Ship the validated 1,324 exercise dataset directly in `src/data/exercisesDataset.json` and export it through `curatedExercises.ts`.
  - *Why*: Querying 1,324 documents from Firestore on every page visit would rapidly exhaust Firebase Spark free-tier quotas (50,000 reads/day) and introduce noticeable network latency. Client-side bundling provides instant, 0ms search, works offline, and costs $0 in cloud operations.
  - *Alternative Considered*: Paginating Firestore collections with `limit(20)` and `startAfter()`. Rejected because it prevents comprehensive multi-facet filtering (Firestore cannot simultaneously do multi-array contains and full-text keyword searches without third-party services like Algolia).

- **Decision 2: Memory & Media Optimization for 1,300+ Animated GIFs**
  - *Chosen Approach*: Paginated virtualized grid (36 items per batch with smooth `"Show More"` or page navigation) paired with poster thumbnail fallbacks until hovered/intersected.
  - *Why*: Loading 1,324 animated GIFs at once would consume 300MB+ of browser RAM and cause frame drops. Progressive lazy loading keeps memory below 25MB and ensures 60fps performance on low-power devices and smart TV browsers.

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                       Workout Companion Console                         │
│                                                                         │
│  ┌───────────────────────┐             ┌─────────────────────────────┐  │
│  │   exercisesDataset.json│             │     Firebase Firestore       │  │
│  │   (1,324 full records)│             │     (exercises collection)  │  │
│  └───────────┬───────────┘             └──────────────┬──────────────┘  │
│              │                                        │                 │
│              ▼                                        ▼                 │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │                   curatedExercises.ts Service                     │  │
│  │  - ALL_DATASET_EXERCISES (1,324 typed Exercise records)           │  │
│  │  - getMergedExercises() (Merges cloud edits with bundled base)    │  │
│  │  - Multi-facet filter helpers (muscles, equipment, difficulty)    │  │
│  └─────────────────────────────────┬─────────────────────────────────┘  │
│                                    │                                    │
│         ┌──────────────────────────┼──────────────────────────┐         │
│         ▼                          ▼                          ▼         │
│  ┌───────────────┐          ┌───────────────┐          ┌─────────────┐  │
│  │ExerciseManager│          │RoutineBuilder │          │ TvSimulator │  │
│  │  - Search Bar │          │  - Exercise   │          │  - Animated │  │
│  │  - Facets Bar │          │    Picker     │          │    Workout  │  │
│  │  - 36-Grid    │          │    Drawer     │          │    Player   │  │
│  │  - Cloud Sync │          │  - Routine    │          │  - Remote   │  │
│  │    Action     │          │    Timeline   │          │    Control  │  │
│  └───────────────┘          └───────────────┘          └─────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
```

### Data Model & Entity Specifications

Each exercise record adheres to the established `Exercise` schema:
```typescript
interface Exercise {
  id: string;                      // Unique ID (e.g., "ex_0001")
  name: string;                    // Human-readable title
  slug: string;                    // URL-safe slug
  description: string;             // Detailed exercise cues
  primaryMuscles: string[];        // Target muscles (e.g. ["Chest", "Triceps"])
  secondaryMuscles: string[];      // Stabilizing muscles
  equipment: string;               // e.g. "Dumbbell", "Body Weight", "Barbell"
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  instructions: string[];          // Step-by-step instructional array
  mediaUrl: string;                // CDN animated GIF URL
  mediaType: 'image/gif';          // Media type descriptor
  posterUrl: string;               // Static WebP/JPG placeholder
  durationSeconds: number;         // Average rep cycle duration
  loop: boolean;                   // Continual animation loop
  sourceUrl: string;               // GitHub repository provenance
  licenceName: string;             // Free personal license
  attributionText: string;         // Attribution line
  status: 'published';             // Publication state
  createdAt: string;               // ISO timestamp
  updatedAt: string;               // ISO timestamp
  createdBy: string;               // System identifier
}
```

### Component Implementation Mapping

1. **`src/data/curatedExercises.ts`**:
   - Export `ALL_DATASET_EXERCISES` with all 1,324 items mapped with default timestamps and IDs.
   - Export unique facet lists: `ALL_MUSCLE_GROUPS` (16 categories), `ALL_EQUIPMENT_TYPES` (14 types), `ALL_DIFFICULTIES`.
   - Export `filterExercises(query, muscle, equipment, difficulty)`.
2. **`src/components/ExerciseManagerView.tsx`**:
   - Update to source from `ALL_DATASET_EXERCISES` merged with any custom user exercises in Firestore.
   - Add responsive multi-facet filter bar:
     - Search input with clear button
     - Primary muscle dropdown (`Abs`, `Biceps`, `Chest`, `Hamstrings`, `Lats`, `Quads`, `Shoulders`, etc.)
     - Equipment filter (`Body Weight`, `Dumbbell`, `Barbell`, `Cable`, `Machine`, etc.)
     - Difficulty filter tabs (`All`, `Beginner`, `Intermediate`, `Advanced`)
   - Add `"Sync to Cloud"` modal with progress bar for admins (using Firestore batches).
   - Display total matching count (e.g. `"Showing 36 of 1,324 exercises"`).
   - Exercise detail modal with full animation playback and `"Add to Routine"` action.
3. **`src/components/RoutineBuilderView.tsx`**:
   - Connect the exercise picker drawer to the complete 1,324 dataset with identical faceted search so users can pick from all 1,324 animations when creating routines.
4. **`src/components/DashboardView.tsx`**:
   - Update exercise stat card to display `1,324` exercises ready for routine building.
